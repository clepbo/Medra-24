(async () => {
  // Medra Organisation — repair pass. Fixes two things in place; renders nothing, deletes nothing.
  //
  //  1. Empty spacer frames. `<Frame grow={1} />` means "push the next thing to the far end".
  //     It has no height, and Figma gives a new frame 100×100 by default, so a 34px row became
  //     100px tall with a hole in it. The frame is set to FILL on the parent's cross axis: a
  //     spacer should take the size of the row it sits in, never dictate it.
  //
  //  2. Text left-aligned inside a centred container. `items="center"` centres the text *node*;
  //     it does not centre the text *inside* the node, so a label reads as left-aligned in a
  //     visibly centred card. Any text in a centred container gets textAlignHorizontal CENTER.
  //
  // Scoped by frame name, not by page — this file's frames are not all on the pages the render
  // script names, because the plan caps the file at three. Set DRY to true to count only.
  const DRY = false;
  if (figma.loadAllPagesAsync) await figma.loadAllPagesAsync();
  const norm = s => (s||'').replace(/&amp;/g,'&').replace(/\s+/g,' ').trim();
  const OWN = new Set(["Org \u00b7 Access \u2014 F1 Who Has Access", "Org \u00b7 Access \u2014 F1 Who Has Access \u00b7 Mobile", "Org \u00b7 Access \u2014 F1 Who Has Access \u00b7 Mobile \u00b7 Requests we have made", "Org \u00b7 Access \u2014 F1 Who Has Access \u00b7 Mobile \u00b7 The organisation never owns the record", "Org \u00b7 Access \u2014 F2 Audit Log", "Org \u00b7 Access \u2014 F2 Audit Log \u00b7 Mobile", "Org \u00b7 Access \u2014 F2 Audit Log \u00b7 Mobile \u00b7 Worth a look", "Org \u00b7 Access \u2014 F3 Privacy & Compliance", "Org \u00b7 Access \u2014 F3 Privacy & Compliance \u00b7 Mobile", "Org \u00b7 Access \u2014 F3 Privacy & Compliance \u00b7 Mobile \u00b7 Shared logins are the risk", "Org \u00b7 Access \u2014 F3 Privacy & Compliance \u00b7 Mobile \u00b7 Where you stand", "Org \u00b7 External \u2014 E10 Done", "Org \u00b7 External \u2014 E10 Done \u00b7 Mobile", "Org \u00b7 External \u2014 E11 Link Expired", "Org \u00b7 External \u2014 E11 Link Expired \u00b7 Mobile", "Org \u00b7 External \u2014 E7 Privacy Notice", "Org \u00b7 External \u2014 E7 Privacy Notice \u00b7 Mobile", "Org \u00b7 External \u2014 E8 What You Are Asked To Do", "Org \u00b7 External \u2014 E8 What You Are Asked To Do \u00b7 Mobile", "Org \u00b7 External \u2014 E9 Upload the Report", "Org \u00b7 External \u2014 E9 Upload the Report \u00b7 Mobile", "Org \u00b7 Front Desk \u2014 D12 The Day", "Org \u00b7 Front Desk \u2014 D12 The Day \u00b7 Mobile", "Org \u00b7 Front Desk \u2014 D12 The Day \u00b7 Mobile \u00b7 Desk actions sheet", "Org \u00b7 Front Desk \u2014 D12 The Day \u00b7 Mobile \u00b7 The whole board", "Org \u00b7 Front Desk \u2014 D13 Register a Walk-in", "Org \u00b7 Front Desk \u2014 D13 Register a Walk-in \u00b7 Mobile", "Org \u00b7 Front Desk \u2014 D13 Register a Walk-in \u00b7 Mobile \u00b7 What they are agreeing to", "Org \u00b7 Front Desk \u2014 D14 Check In", "Org \u00b7 Front Desk \u2014 D14 Check In \u00b7 Mobile", "Org \u00b7 Front Desk \u2014 D14 Check In \u00b7 Mobile \u00b7 Insurance on her profile", "Org \u00b7 Front Desk \u2014 D14 Check In \u00b7 Mobile \u00b7 Then what?", "Org \u00b7 Laboratory \u2014 D5 Order Queue", "Org \u00b7 Laboratory \u2014 D5 Order Queue \u00b7 Mobile", "Org \u00b7 Laboratory \u2014 D5 Order Queue \u00b7 Mobile \u00b7 In progress", "Org \u00b7 Laboratory \u2014 D5 Order Queue \u00b7 Mobile \u00b7 Today", "Org \u00b7 Laboratory \u2014 D6 Order", "Org \u00b7 Laboratory \u2014 D6 Order \u00b7 Mobile", "Org \u00b7 Laboratory \u2014 D6 Order \u00b7 Mobile \u00b7 Her previous results", "Org \u00b7 Laboratory \u2014 D6 Order \u00b7 Mobile \u00b7 What you can and cannot see", "Org \u00b7 Laboratory \u2014 D7 Enter Result", "Org \u00b7 Laboratory \u2014 D7 Enter Result \u00b7 Mobile", "Org \u00b7 Laboratory \u2014 D7 Enter Result \u00b7 Mobile \u00b7 What happens when you finish", "Org \u00b7 Laboratory \u2014 D7 Enter Result \u00b7 Mobile \u00b7 Why a form and not a paragraph", "Org \u00b7 Laboratory \u2014 D8 Sample Problem", "Org \u00b7 Laboratory \u2014 D8 Sample Problem \u00b7 Mobile", "Org \u00b7 Laboratory \u2014 D8 Sample Problem \u00b7 Mobile \u00b7 What should happen now", "Org \u00b7 Laboratory \u2014 D8 Sample Problem \u00b7 Mobile \u00b7 Why this screen exists", "Org \u00b7 Nursing \u2014 D1 My Queue", "Org \u00b7 Nursing \u2014 D1 My Queue \u00b7 Mobile", "Org \u00b7 Nursing \u2014 D1 My Queue \u00b7 Mobile \u00b7 Done today", "Org \u00b7 Nursing \u2014 D1 My Queue \u00b7 Mobile \u00b7 Standing orders", "Org \u00b7 Nursing \u2014 D2 Record Vitals", "Org \u00b7 Nursing \u2014 D2 Record Vitals \u00b7 Mobile", "Org \u00b7 Nursing \u2014 D2 Record Vitals \u00b7 Mobile \u00b7 Against her own history", "Org \u00b7 Nursing \u2014 D2 Record Vitals \u00b7 Mobile \u00b7 What she told us herself", "Org \u00b7 Nursing \u2014 D3 Administer & Record", "Org \u00b7 Nursing \u2014 D3 Administer & Record \u00b7 Mobile", "Org \u00b7 Nursing \u2014 D3 Administer & Record \u00b7 Mobile \u00b7 After you give it", "Org \u00b7 Nursing \u2014 D3 Administer & Record \u00b7 Mobile \u00b7 Before you give it", "Org \u00b7 Nursing \u2014 D3 Administer & Record \u00b7 Mobile \u00b7 The course", "Org \u00b7 Nursing \u2014 D4 Escalate", "Org \u00b7 Nursing \u2014 D4 Escalate \u00b7 Mobile", "Org \u00b7 Nursing \u2014 D4 Escalate \u00b7 Mobile \u00b7 What you found", "Org \u00b7 Nursing \u2014 D4 Escalate \u00b7 Mobile \u00b7 Who this goes to", "Org \u00b7 People \u2014 C1 Departments", "Org \u00b7 People \u2014 C1 Departments \u00b7 Mobile", "Org \u00b7 People \u2014 C1 Departments \u00b7 Mobile \u00b7 Seats", "Org \u00b7 People \u2014 C1 Departments \u00b7 Mobile \u00b7 Why departments, not people", "Org \u00b7 People \u2014 C2 Department", "Org \u00b7 People \u2014 C2 Department \u00b7 Mobile", "Org \u00b7 People \u2014 C2 Department \u00b7 Mobile \u00b7 People in this department", "Org \u00b7 People \u2014 C2 Department \u00b7 Mobile \u00b7 What this department can do", "Org \u00b7 People \u2014 C3 Add a Department", "Org \u00b7 People \u2014 C3 Add a Department \u00b7 Mobile", "Org \u00b7 People \u2014 C3 Add a Department \u00b7 Mobile \u00b7 What it will be able to do", "Org \u00b7 People \u2014 C4 People", "Org \u00b7 People \u2014 C4 People \u00b7 Mobile", "Org \u00b7 People \u2014 C4 People \u00b7 Mobile \u00b7 Needs you", "Org \u00b7 People \u2014 C5 Invite Someone", "Org \u00b7 People \u2014 C5 Invite Someone \u00b7 Mobile", "Org \u00b7 People \u2014 C5 Invite Someone \u00b7 Mobile \u00b7 What happens next", "Org \u00b7 People \u2014 C5 Invite Someone \u00b7 Mobile \u00b7 What they will be able to do", "Org \u00b7 People \u2014 C6 Person", "Org \u00b7 People \u2014 C6 Person \u00b7 Mobile", "Org \u00b7 People \u2014 C6 Person \u00b7 Mobile \u00b7 Managing this seat", "Org \u00b7 People \u2014 C6 Person \u00b7 Mobile \u00b7 What she can see", "Org \u00b7 People \u2014 C6 Person \u00b7 Mobile \u00b7 What she has done today", "Org \u00b7 People \u2014 C7 Roles & Permissions", "Org \u00b7 People \u2014 C7 Roles & Permissions \u00b7 Mobile", "Org \u00b7 People \u2014 C7 Roles & Permissions \u00b7 Mobile \u00b7 How access ends", "Org \u00b7 People \u2014 C7 Roles & Permissions \u00b7 Mobile \u00b7 Who can do what", "Org \u00b7 Pharmacy \u2014 D10 Dispense", "Org \u00b7 Pharmacy \u2014 D10 Dispense \u00b7 Mobile", "Org \u00b7 Pharmacy \u2014 D10 Dispense \u00b7 Mobile \u00b7 Say this at the counter", "Org \u00b7 Pharmacy \u2014 D11 Cannot Dispense", "Org \u00b7 Pharmacy \u2014 D11 Cannot Dispense \u00b7 Mobile", "Org \u00b7 Pharmacy \u2014 D11 Cannot Dispense \u00b7 Mobile \u00b7 What the doctor will see", "Org \u00b7 Pharmacy \u2014 D11 Cannot Dispense \u00b7 Mobile \u00b7 What we could give instead", "Org \u00b7 Pharmacy \u2014 D9 Prescription Queue", "Org \u00b7 Pharmacy \u2014 D9 Prescription Queue \u00b7 Mobile", "Org \u00b7 Pharmacy \u2014 D9 Prescription Queue \u00b7 Mobile \u00b7 Watch the shelf", "Org \u00b7 Referrals \u2014 E1 Referred Out", "Org \u00b7 Referrals \u2014 E1 Referred Out \u00b7 Mobile", "Org \u00b7 Referrals \u2014 E1 Referred Out \u00b7 Mobile \u00b7 How referrals are going", "Org \u00b7 Referrals \u2014 E2 Refer Someone", "Org \u00b7 Referrals \u2014 E2 Refer Someone \u00b7 Mobile", "Org \u00b7 Referrals \u2014 E2 Refer Someone \u00b7 Mobile \u00b7 What they will see", "Org \u00b7 Referrals \u2014 E2 Refer Someone \u00b7 Mobile \u00b7 What you are asking for", "Org \u00b7 Referrals \u2014 E2 Refer Someone \u00b7 Mobile \u00b7 Who it is for", "Org \u00b7 Referrals \u2014 E3 Referral Sent", "Org \u00b7 Referrals \u2014 E3 Referral Sent \u00b7 Mobile", "Org \u00b7 Referrals \u2014 E3 Referral Sent \u00b7 Mobile \u00b7 The link they will get", "Org \u00b7 Referrals \u2014 E3 Referral Sent \u00b7 Mobile \u00b7 What happens next", "Org \u00b7 Referrals \u2014 E4 Referred To Us", "Org \u00b7 Referrals \u2014 E4 Referred To Us \u00b7 Mobile", "Org \u00b7 Referrals \u2014 E4 Referred To Us \u00b7 Mobile \u00b7 Save yourself this screen", "Org \u00b7 Referrals \u2014 E5 Referral Detail", "Org \u00b7 Referrals \u2014 E5 Referral Detail \u00b7 Mobile", "Org \u00b7 Referrals \u2014 E5 Referral Detail \u00b7 Mobile \u00b7 What Halima shared", "Org \u00b7 Referrals \u2014 E5 Referral Detail \u00b7 Mobile \u00b7 Your answer", "Org \u00b7 Referrals \u2014 E6 Single-use Links", "Org \u00b7 Referrals \u2014 E6 Single-use Links \u00b7 Mobile", "Org \u00b7 Referrals \u2014 E6 Single-use Links \u00b7 Mobile \u00b7 Rules that apply to every link", "Org \u00b7 Referrals \u2014 E6 Single-use Links \u00b7 Mobile \u00b7 Why a link and not an account", "Org \u00b7 Reports \u2014 F4 Reports", "Org \u00b7 Reports \u2014 F4 Reports \u00b7 Mobile", "Org \u00b7 Reports \u2014 F4 Reports \u00b7 Mobile \u00b7 Things worth watching", "Org \u00b7 Reports \u2014 F4 Reports \u00b7 Mobile \u00b7 Where the load is", "Org \u00b7 Settings \u2014 F5 Organisation Settings", "Org \u00b7 Settings \u2014 F5 Organisation Settings \u00b7 Mobile", "Org \u00b7 Settings \u2014 F5 Organisation Settings \u00b7 Mobile \u00b7 Branches, departments and profile", "Org \u00b7 Settings \u2014 F5 Organisation Settings \u00b7 Mobile \u00b7 How people reach you", "Org \u00b7 Settings \u2014 F5 Organisation Settings \u00b7 Mobile \u00b7 Policies members are shown", "Org \u00b7 Settings \u2014 F5 Organisation Settings \u00b7 Mobile \u00b7 When you are open", "Org \u00b7 Settings \u2014 F6 Subscription", "Org \u00b7 Settings \u2014 F6 Subscription \u00b7 Mobile", "Org \u00b7 Settings \u2014 F6 Subscription \u00b7 Mobile \u00b7 Invoices", "Org \u00b7 Settings \u2014 F6 Subscription \u00b7 Mobile \u00b7 What it covers", "Org \u00b7 Setup \u2014 A1 Setup Checklist", "Org \u00b7 Setup \u2014 A1 Setup Checklist \u00b7 Mobile", "Org \u00b7 Setup \u2014 A1 Setup Checklist \u00b7 Mobile \u00b7 The seven steps", "Org \u00b7 Setup \u2014 A1 Setup Checklist \u00b7 Mobile \u00b7 What being live gets you", "Org \u00b7 Setup \u2014 A2 Verification", "Org \u00b7 Setup \u2014 A2 Verification \u00b7 Mobile", "Org \u00b7 Setup \u2014 A2 Verification \u00b7 Mobile \u00b7 Documents", "Org \u00b7 Setup \u2014 A2 Verification \u00b7 Mobile \u00b7 Where your application is", "Org \u00b7 Setup \u2014 A2 Verification \u00b7 Mobile \u00b7 Worth doing while you wait", "Org \u00b7 Setup \u2014 A3 Branches", "Org \u00b7 Setup \u2014 A3 Branches \u00b7 Mobile", "Org \u00b7 Setup \u2014 A3 Branches \u00b7 Mobile \u00b7 Add a branch", "Org \u00b7 Setup \u2014 A4 Plan & Seats", "Org \u00b7 Setup \u2014 A4 Plan & Seats \u00b7 Mobile", "Org \u00b7 Setup \u2014 A4 Plan & Seats \u00b7 Mobile \u00b7 Plans", "Org \u00b7 Setup \u2014 A4 Plan & Seats \u00b7 Mobile \u00b7 What you are buying", "Org \u00b7 Setup \u2014 A4 Plan & Seats \u00b7 Mobile \u00b7 Your size", "Org \u00b7 Setup \u2014 A5 Public Profile", "Org \u00b7 Setup \u2014 A5 Public Profile \u00b7 Mobile", "Org \u00b7 Setup \u2014 A5 Public Profile \u00b7 Mobile \u00b7 Edit the profile", "Org \u00b7 Setup \u2014 A5 Public Profile \u00b7 Mobile \u00b7 How members see you", "Org \u00b7 States \u2014 X1 Seats Full", "Org \u00b7 States \u2014 X1 Seats Full \u00b7 Mobile", "Org \u00b7 States \u2014 X1 Seats Full \u00b7 Mobile \u00b7 Three ways out", "Org \u00b7 States \u2014 X2 Not Yet Verified", "Org \u00b7 States \u2014 X2 Not Yet Verified \u00b7 Mobile", "Org \u00b7 States \u2014 X2 Not Yet Verified \u00b7 Mobile \u00b7 What works right now", "Org \u00b7 States \u2014 X3 Subscription Locked", "Org \u00b7 States \u2014 X3 Subscription Locked \u00b7 Mobile", "Org \u00b7 States \u2014 X3 Subscription Locked \u00b7 Mobile \u00b7 What has stopped", "Org \u00b7 States \u2014 X3 Subscription Locked \u00b7 Mobile \u00b7 What is still true", "Org \u00b7 States \u2014 X4 Nothing Booked", "Org \u00b7 States \u2014 X4 Nothing Booked \u00b7 Mobile", "Org \u00b7 States \u2014 X4 Nothing Booked \u00b7 Mobile \u00b7 What usually causes this", "Org \u00b7 States \u2014 X5 Offline", "Org \u00b7 States \u2014 X5 Offline \u00b7 Mobile", "Org \u00b7 States \u2014 X5 Offline \u00b7 Mobile \u00b7 What still works", "Org \u00b7 States \u2014 X5 Offline \u00b7 Mobile \u00b7 What waits", "Org \u00b7 States \u2014 X6 Error", "Org \u00b7 States \u2014 X6 Error \u00b7 Mobile", "Org \u00b7 States \u2014 X6 Error \u00b7 Mobile \u00b7 If people are waiting", "Org \u00b7 States \u2014 X6 Error \u00b7 Mobile \u00b7 What is safe", "Org \u00b7 States \u2014 X7 Loading", "Org \u00b7 States \u2014 X7 Loading \u00b7 Mobile", "Org \u00b7 Today \u2014 B1 Today", "Org \u00b7 Today \u2014 B1 Today \u00b7 Mobile", "Org \u00b7 Today \u2014 B1 Today \u00b7 Mobile \u00b7 Across the branches", "Org \u00b7 Today \u2014 B1 Today \u00b7 Mobile \u00b7 Departments", "Org \u00b7 Today \u2014 B1 Today \u00b7 Mobile \u00b7 Now in the building", "Org \u00b7 Today \u2014 B1 Today \u00b7 Mobile \u00b7 Quick actions sheet", "Org \u00b7 Today \u2014 B2 Bookings & Allocation", "Org \u00b7 Today \u2014 B2 Bookings & Allocation \u00b7 Mobile", "Org \u00b7 Today \u2014 B2 Bookings & Allocation \u00b7 Mobile \u00b7 Already assigned", "Org \u00b7 Today \u2014 B2 Bookings & Allocation \u00b7 Mobile \u00b7 Assign someone sheet", "Org \u00b7 Today \u2014 B2 Bookings & Allocation \u00b7 Mobile \u00b7 The four in full", "Org \u00b7 Today \u2014 B2 Bookings & Allocation \u00b7 Mobile \u00b7 Who is free", "Org \u00b7 Today \u2014 B3 Find a Member", "Org \u00b7 Today \u2014 B3 Find a Member \u00b7 Mobile", "Org \u00b7 Today \u2014 B3 Find a Member \u00b7 Mobile \u00b7 Cannot find them?", "cmp/Access Link/State=Expired", "cmp/Access Link/State=Open", "cmp/Access Link/State=Revoked", "cmp/Access Link/State=Used", "cmp/Department Card/Kind=Consulting", "cmp/Department Card/Kind=Frontdesk", "cmp/Department Card/Kind=Laboratory", "cmp/Department Card/Kind=Nursing", "cmp/Department Card/Kind=Pharmacy", "cmp/Health Fact/State=Unverified", "cmp/Health Fact/State=Verified", "cmp/Permission Row/State=Allowed", "cmp/Permission Row/State=Denied", "cmp/Result Line/Flag=High", "cmp/Result Line/Flag=Low", "cmp/Result Line/Flag=Normal", "cmp/Seat Row/State=Active", "cmp/Seat Row/State=Invited", "cmp/Seat Row/State=Suspended"].map(norm));

  // every top-level frame in the file that belongs to this module, wherever it sits
  const roots = [], onPages = {};
  for (const pg of figma.root.children) {
    if (pg.type !== 'PAGE') continue;
    for (const f of pg.children) {
      if (f.type === 'FRAME' && OWN.has(norm(f.name))) {
        roots.push(f); onPages[pg.name] = (onPages[pg.name] || 0) + 1;
      }
    }
  }
  if (!roots.length) return { error: 'no frames from this module found in this file',
                              expectedFrames: OWN.size,
                              pagesInFile: figma.root.children.filter(n=>n.type==='PAGE').map(p=>p.name) };

  // A spacer is empty AND invisible. A frame with a fill or a stroke is a drawn block, and
  // resizing one of those would be a design change, not a repair.
  const invisible = n => {
    const f = n.fills, s = n.strokes;
    const hasFill = Array.isArray(f) && f.some(p => p.visible !== false && p.opacity !== 0);
    const hasStroke = Array.isArray(s) && s.length > 0;
    return !hasFill && !hasStroke;
  };

  // Text properties cannot be touched until every font on the node is loaded.
  const seen = new Set(), fonts = [];
  const collect = n => {
    if (n.type === 'TEXT') {
      let fs; try { fs = n.getRangeAllFontNames(0, n.characters.length); } catch (e) { fs = []; }
      for (const f of fs) { const k = f.family + '|' + f.style;
        if (!seen.has(k)) { seen.add(k); fonts.push(f); } }
    }
    if ('children' in n) n.children.forEach(collect);
  };
  roots.forEach(collect);
  for (const f of fonts) { try { await figma.loadFontAsync(f); } catch (e) {} }

  let spacers = 0, texts = 0, scanned = 0, failed = 0;
  const notes = [], samples = [];

  const walk = n => {
    scanned++;
    const auto = 'layoutMode' in n && n.layoutMode && n.layoutMode !== 'NONE';
    if (auto && n.children.length > 1) {
      const row = n.layoutMode === 'HORIZONTAL';
      for (const kid of n.children) {
        if (kid.type === 'FRAME' && kid.children.length === 0 && invisible(kid)) {
          const prop = row ? 'layoutSizingVertical' : 'layoutSizingHorizontal';
          if (kid[prop] !== 'FILL') {
            if (samples.length < 8) samples.push((n.name||'Frame') + ' \u2192 ' + (row?'height':'width') + ' was ' + Math.round(row?kid.height:kid.width));
            if (!DRY) {
              try { kid[prop] = 'FILL'; spacers++; }
              catch (e) {
                // FILL refused (a fixed-size parent, usually) \u2014 collapse it instead, same result
                try { kid.resize(row ? Math.max(kid.width,0.01) : 0.01, row ? 0.01 : Math.max(kid.height,0.01)); spacers++; }
                catch (e2) { failed++; if (notes.length < 10) notes.push((n.name||'?') + ': ' + e2.message); }
              }
            } else spacers++;
          }
        }
        if (kid.type === 'TEXT') {
          const centred = (!row && n.counterAxisAlignItems === 'CENTER')
                       || ( row && n.primaryAxisAlignItems === 'CENTER');
          if (centred && kid.textAlignHorizontal !== 'CENTER') {
            if (!DRY) {
              try { kid.textAlignHorizontal = 'CENTER'; texts++; }
              catch (e) { failed++; if (notes.length < 10) notes.push('text \u201c' + (kid.characters||'').slice(0,24) + '\u201d: ' + e.message); }
            } else texts++;
          }
        }
      }
    }
    if ('children' in n) n.children.forEach(walk);
  };
  roots.forEach(walk);

  return { dryRun: DRY, framesRepaired: roots.length, framesExpected: OWN.size,
           foundOnPages: onPages, spacersCollapsed: spacers, textCentred: texts,
           nodesScanned: scanned, failed, examples: samples, notes };
})();
